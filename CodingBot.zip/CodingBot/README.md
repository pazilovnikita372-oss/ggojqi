# Coding Bot 2.0
Работает офлайн (302 статьи + справочник Python stdlib) без ключей.
Онлайн-ИИ: ☰ → Настройки → «Добавить провайдера».
Сборка: GitHub Actions (см. workflow) или Android Studio → Build APK.
