### SQL: SELECT основы | sql select where order by limit запрос выборка | SQL
```sql
SELECT id, name, price
FROM products
WHERE price > 100 AND category = 'books'
ORDER BY price DESC
LIMIT 10 OFFSET 20;
```

### SQL: JOIN объединение таблиц | sql join inner left right full соединение таблиц | SQL
```sql
-- только совпадения
SELECT o.id, c.name
FROM orders o
INNER JOIN customers c ON c.id = o.customer_id;

-- все заказы, даже без клиента
SELECT o.id, c.name
FROM orders o
LEFT JOIN customers c ON c.id = o.customer_id;
```
INNER: пересечение. LEFT: все из левой + совпавшие справа (иначе NULL).

### SQL: GROUP BY и агрегаты | sql group by having count sum avg агрегация группировка | SQL
```sql
SELECT category, COUNT(*) AS n, AVG(price) AS avg_price
FROM products
GROUP BY category
HAVING COUNT(*) > 5
ORDER BY n DESC;
```
WHERE фильтрует строки до группировки, HAVING: после.

### SQL: INSERT UPDATE DELETE | sql insert update delete изменение данных вставка | SQL
```sql
INSERT INTO users (name, email) VALUES ('Ann', 'a@x.com');
UPDATE users SET name = 'Anna' WHERE id = 1;
DELETE FROM users WHERE id = 1;
```
Всегда проверяй WHERE: без него изменятся все строки.

### SQL: CREATE TABLE | sql create table типы ключи constraints создать таблицу | SQL
```sql
CREATE TABLE users (
  id         BIGINT PRIMARY KEY,
  email      VARCHAR(255) NOT NULL UNIQUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE posts (
  id      BIGINT PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title   TEXT NOT NULL
);
CREATE INDEX idx_posts_user ON posts(user_id);
```

### SQL: индексы и скорость | sql index индекс explain медленный запрос оптимизация | SQL
- Индексируй колонки в WHERE, JOIN, ORDER BY.
- `EXPLAIN ANALYZE` покажет реальный план.
- Функция над колонкой в WHERE (`LOWER(email)=...`) ломает обычный индекс.
- Лишние индексы замедляют запись.
```sql
EXPLAIN ANALYZE SELECT * FROM posts WHERE user_id = 5;
```

### SQL: подзапросы и CTE | sql subquery cte with подзапрос | SQL
```sql
WITH top AS (
  SELECT customer_id, SUM(total) AS s
  FROM orders GROUP BY customer_id
)
SELECT c.name, top.s
FROM top JOIN customers c ON c.id = top.customer_id
WHERE top.s > 1000;
```

### SQL: оконные функции | sql window function row_number rank over оконные | SQL
```sql
SELECT name, dept, salary,
       RANK() OVER (PARTITION BY dept ORDER BY salary DESC) AS r
FROM employees;
```

### SQL: SQL-инъекции | sql injection инъекция безопасность параметризованные запросы | SQL
Никогда не склеивай запрос из пользовательского ввода. Используй параметры:
```python
cur.execute("SELECT * FROM users WHERE email = %s", (email,))
```
```java
var ps = conn.prepareStatement("SELECT * FROM users WHERE email = ?");
ps.setString(1, email);
```

### SQL: транзакции | sql transaction commit rollback acid транзакция | SQL
```sql
BEGIN;
UPDATE accounts SET balance = balance - 100 WHERE id = 1;
UPDATE accounts SET balance = balance + 100 WHERE id = 2;
COMMIT;   -- или ROLLBACK при ошибке
```

### SQLite в Android | sqlite android room база данных | Android
```kotlin
@Entity data class Note(@PrimaryKey(autoGenerate = true) val id: Long = 0, val text: String)

@Dao interface NoteDao {
    @Query("SELECT * FROM Note") suspend fun all(): List<Note>
    @Insert suspend fun add(n: Note)
}
```
Нужны зависимости `androidx.room:room-runtime`, `room-ktx` и kapt/ksp для компилятора.
