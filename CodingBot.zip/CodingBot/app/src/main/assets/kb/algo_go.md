### Бинарный поиск (Go) | binary search бинарный поиск sorted array отсортированный массив O(log n) go Go | Go
```go
func binarySearch(a []int, x int) int {
	lo, hi := 0, len(a)-1
	for lo <= hi {
		mid := lo + (hi-lo)/2
		if a[mid] == x {
			return mid
		} else if a[mid] < x {
			lo = mid + 1
		} else {
			hi = mid - 1
		}
	}
	return -1
}
```

### Быстрая сортировка (Go) | quicksort быстрая сортировка sort сортировка алгоритм O(n log n) go Go | Go
```go
func quicksort(a []int) []int {
	if len(a) <= 1 {
		return a
	}
	p := a[len(a)/2]
	var l, m, r []int
	for _, x := range a {
		switch {
		case x < p:
			l = append(l, x)
		case x == p:
			m = append(m, x)
		default:
			r = append(r, x)
		}
	}
	res := append(quicksort(l), m...)
	return append(res, quicksort(r)...)
}
```

### Сортировка слиянием (Go) | merge sort сортировка слиянием sort алгоритм stable стабильная go Go | Go
```go
func mergeSort(a []int) []int {
	if len(a) <= 1 {
		return a
	}
	m := len(a) / 2
	l, r := mergeSort(a[:m]), mergeSort(a[m:])
	out := make([]int, 0, len(a))
	i, j := 0, 0
	for i < len(l) && j < len(r) {
		if l[i] <= r[j] {
			out = append(out, l[i]); i++
		} else {
			out = append(out, r[j]); j++
		}
	}
	out = append(out, l[i:]...)
	return append(out, r[j:]...)
}
```

### Числа Фибоначчи (Go) | fibonacci фибоначчи число recursion рекурсия итерация go Go | Go
```go
func fib(n int) uint64 {
	var a, b uint64 = 0, 1
	for i := 0; i < n; i++ {
		a, b = b, a+b
	}
	return a
}
```

### Проверка на простое число (Go) | prime простое число is_prime простые sieve решето go Go | Go
```go
func isPrime(n int) bool {
	if n < 2 {
		return false
	}
	for i := 2; i*i <= n; i++ {
		if n%i == 0 {
			return false
		}
	}
	return true
}
```

### Разворот строки (Go) | reverse string развернуть строку reverse перевернуть go Go | Go
```go
func reverse(s string) string {
	r := []rune(s)
	for i, j := 0, len(r)-1; i < j; i, j = i+1, j-1 {
		r[i], r[j] = r[j], r[i]
	}
	return string(r)
}
```

### Палиндром (Go) | palindrome палиндром проверка строка go Go | Go
```go
func isPalindrome(s string) bool {
	var t []rune
	for _, c := range strings.ToLower(s) {
		if unicode.IsLetter(c) || unicode.IsDigit(c) {
			t = append(t, c)
		}
	}
	for i, j := 0, len(t)-1; i < j; i, j = i+1, j-1 {
		if t[i] != t[j] {
			return false
		}
	}
	return true
}
```

### Наибольший общий делитель (НОД) (Go) | gcd нод greatest common divisor euclid евклид go Go | Go
```go
func gcd(a, b int) int {
	for b != 0 {
		a, b = b, a%b
	}
	return a
}
```

### Подсчёт слов в тексте (Go) | count words частота слов word frequency hashmap словарь dictionary go Go | Go
```go
func wordFreq(text string) map[string]int {
	m := map[string]int{}
	for _, w := range strings.Fields(strings.ToLower(text)) {
		m[w]++
	}
	return m
}
```

### Чтение файла построчно (Go) | read file чтение файла построчно file io open go Go | Go
```go
f, err := os.Open("data.txt")
if err != nil { log.Fatal(err) }
defer f.Close()
sc := bufio.NewScanner(f)
for sc.Scan() {
	fmt.Println(sc.Text())
}
```

### HTTP GET запрос (Go) | http get запрос request fetch api rest json go Go | Go
```go
resp, err := http.Get("https://api.example.com/items")
if err != nil { log.Fatal(err) }
defer resp.Body.Close()
body, _ := io.ReadAll(resp.Body)
```

### Разбор JSON (Go) | json parse разбор json serialize сериализация десериализация go Go | Go
```go
var v map[string]any
if err := json.Unmarshal([]byte(`{"a":1}`), &v); err != nil { log.Fatal(err) }
b, _ := json.MarshalIndent(v, "", "  ")
```

### FizzBuzz (Go) | fizzbuzz физзбазз loops циклы условия go Go | Go
```go
for i := 1; i <= 100; i++ {
	switch {
	case i%15 == 0:
		fmt.Println("FizzBuzz")
	case i%3 == 0:
		fmt.Println("Fizz")
	case i%5 == 0:
		fmt.Println("Buzz")
	default:
		fmt.Println(i)
	}
}
```

### Класс и наследование (Go) | class inheritance класс наследование ооп oop interface интерфейс go Go | Go
```go
type Animal interface{ Speak() string }

type Dog struct{ Name string }

func (d Dog) Speak() string { return d.Name + ": Гав!" }
```

### Обработка ошибок (Go) | error handling exceptions обработка ошибок исключения try catch go Go | Go
```go
n, err := strconv.Atoi(text)
if err != nil {
	return fmt.Errorf("parse %q: %w", text, err)
}
```

### Потоки и параллелизм (Go) | thread async parallel потоки асинхронность concurrency корутины coroutine go Go | Go
```go
var wg sync.WaitGroup
for i := 0; i < 5; i++ {
	wg.Add(1)
	go func(i int) {
		defer wg.Done()
		fmt.Println(i * 2)
	}(i)
}
wg.Wait()
```
