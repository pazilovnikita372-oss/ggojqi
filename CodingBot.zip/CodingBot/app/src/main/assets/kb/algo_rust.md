### Бинарный поиск (Rust) | binary search бинарный поиск sorted array отсортированный массив O(log n) rust Rust | Rust
```rust
fn binary_search(a: &[i32], x: i32) -> Option<usize> {
    let (mut lo, mut hi) = (0usize, a.len());
    while lo < hi {
        let mid = lo + (hi - lo) / 2;
        if a[mid] == x { return Some(mid); }
        if a[mid] < x { lo = mid + 1; } else { hi = mid; }
    }
    None
}
```

### Быстрая сортировка (Rust) | quicksort быстрая сортировка sort сортировка алгоритм O(n log n) rust Rust | Rust
```rust
fn quicksort(a: &mut [i32]) {
    if a.len() <= 1 { return; }
    let p = a[a.len() / 2];
    let (mut i, mut j) = (0usize, a.len() - 1);
    loop {
        while a[i] < p { i += 1; }
        while a[j] > p { j -= 1; }
        if i >= j { break; }
        a.swap(i, j);
        i += 1;
        j -= 1;
    }
    let (l, r) = a.split_at_mut(i);
    quicksort(l);
    quicksort(r);
}
```

### Сортировка слиянием (Rust) | merge sort сортировка слиянием sort алгоритм stable стабильная rust Rust | Rust
```rust
fn merge_sort(a: Vec<i32>) -> Vec<i32> {
    if a.len() <= 1 { return a; }
    let m = a.len() / 2;
    let r = merge_sort(a[m..].to_vec());
    let l = merge_sort(a[..m].to_vec());
    let (mut i, mut j) = (0, 0);
    let mut out = Vec::with_capacity(l.len() + r.len());
    while i < l.len() && j < r.len() {
        if l[i] <= r[j] { out.push(l[i]); i += 1; } else { out.push(r[j]); j += 1; }
    }
    out.extend_from_slice(&l[i..]);
    out.extend_from_slice(&r[j..]);
    out
}
```

### Числа Фибоначчи (Rust) | fibonacci фибоначчи число recursion рекурсия итерация rust Rust | Rust
```rust
fn fib(n: u32) -> u64 {
    let (mut a, mut b) = (0u64, 1u64);
    for _ in 0..n { let t = a + b; a = b; b = t; }
    a
}
```

### Проверка на простое число (Rust) | prime простое число is_prime простые sieve решето rust Rust | Rust
```rust
fn is_prime(n: u64) -> bool {
    if n < 2 { return false; }
    let mut i = 2;
    while i * i <= n {
        if n % i == 0 { return false; }
        i += 1;
    }
    true
}
```

### Разворот строки (Rust) | reverse string развернуть строку reverse перевернуть rust Rust | Rust
```rust
fn reverse(s: &str) -> String {
    s.chars().rev().collect()
}
```

### Палиндром (Rust) | palindrome палиндром проверка строка rust Rust | Rust
```rust
fn is_palindrome(s: &str) -> bool {
    let t: Vec<char> = s.chars().filter(|c| c.is_alphanumeric())
        .flat_map(|c| c.to_lowercase()).collect();
    t.iter().eq(t.iter().rev())
}
```

### Наибольший общий делитель (НОД) (Rust) | gcd нод greatest common divisor euclid евклид rust Rust | Rust
```rust
fn gcd(a: u64, b: u64) -> u64 {
    if b == 0 { a } else { gcd(b, a % b) }
}
```

### Подсчёт слов в тексте (Rust) | count words частота слов word frequency hashmap словарь dictionary rust Rust | Rust
```rust
use std::collections::HashMap;
fn word_freq(text: &str) -> HashMap<String, usize> {
    let mut m = HashMap::new();
    for w in text.split_whitespace() {
        *m.entry(w.to_lowercase()).or_insert(0) += 1;
    }
    m
}
```

### Чтение файла построчно (Rust) | read file чтение файла построчно file io open rust Rust | Rust
```rust
use std::io::{BufRead, BufReader};
let f = std::fs::File::open("data.txt")?;
for line in BufReader::new(f).lines() {
    println!("{}", line?);
}
```

### HTTP GET запрос (Rust) | http get запрос request fetch api rest json rust Rust | Rust
```rust
// reqwest = { version = "0.12", features = ["blocking", "json"] }
let text = reqwest::blocking::get("https://api.example.com/items")?.text()?;
```

### Разбор JSON (Rust) | json parse разбор json serialize сериализация десериализация rust Rust | Rust
```rust
// serde_json
let v: serde_json::Value = serde_json::from_str(r#"{"a":1}"#)?;
let s = serde_json::to_string_pretty(&v)?;
```

### FizzBuzz (Rust) | fizzbuzz физзбазз loops циклы условия rust Rust | Rust
```rust
for i in 1..=100 {
    match (i % 3, i % 5) {
        (0, 0) => println!("FizzBuzz"),
        (0, _) => println!("Fizz"),
        (_, 0) => println!("Buzz"),
        _ => println!("{}", i),
    }
}
```

### Класс и наследование (Rust) | class inheritance класс наследование ооп oop interface интерфейс rust Rust | Rust
```rust
trait Animal { fn speak(&self) -> String; }
struct Dog { name: String }
impl Animal for Dog {
    fn speak(&self) -> String { format!("{}: Гав!", self.name) }
}
```

### Обработка ошибок (Rust) | error handling exceptions обработка ошибок исключения try catch rust Rust | Rust
```rust
fn parse(t: &str) -> Result<i32, std::num::ParseIntError> {
    t.parse::<i32>()
}
match parse("12") {
    Ok(n) => println!("{n}"),
    Err(e) => eprintln!("{e}"),
}
```

### Потоки и параллелизм (Rust) | thread async parallel потоки асинхронность concurrency корутины coroutine rust Rust | Rust
```rust
let hs: Vec<_> = (0..5).map(|i| std::thread::spawn(move || i * 2)).collect();
for h in hs { println!("{}", h.join().unwrap()); }
```
