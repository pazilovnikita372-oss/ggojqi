### Бинарный поиск (Kotlin) | binary search бинарный поиск sorted array отсортированный массив O(log n) kotlin Kotlin | Kotlin
```kotlin
fun binarySearch(a: IntArray, x: Int): Int {
    var lo = 0
    var hi = a.size - 1
    while (lo <= hi) {
        val mid = (lo + hi) ushr 1
        when {
            a[mid] == x -> return mid
            a[mid] < x -> lo = mid + 1
            else -> hi = mid - 1
        }
    }
    return -1
}
```

### Быстрая сортировка (Kotlin) | quicksort быстрая сортировка sort сортировка алгоритм O(n log n) kotlin Kotlin | Kotlin
```kotlin
fun quicksort(a: List<Int>): List<Int> {
    if (a.size <= 1) return a
    val p = a[a.size / 2]
    return quicksort(a.filter { it < p }) + a.filter { it == p } + quicksort(a.filter { it > p })
}
```

### Сортировка слиянием (Kotlin) | merge sort сортировка слиянием sort алгоритм stable стабильная kotlin Kotlin | Kotlin
```kotlin
fun mergeSort(a: List<Int>): List<Int> {
    if (a.size <= 1) return a
    val m = a.size / 2
    val l = mergeSort(a.subList(0, m))
    val r = mergeSort(a.subList(m, a.size))
    val out = ArrayList<Int>(a.size)
    var i = 0; var j = 0
    while (i < l.size && j < r.size) out.add(if (l[i] <= r[j]) l[i++] else r[j++])
    while (i < l.size) out.add(l[i++])
    while (j < r.size) out.add(r[j++])
    return out
}
```

### Числа Фибоначчи (Kotlin) | fibonacci фибоначчи число recursion рекурсия итерация kotlin Kotlin | Kotlin
```kotlin
fun fib(n: Int): Long {
    var a = 0L; var b = 1L
    repeat(n) { val t = a + b; a = b; b = t }
    return a
}
```

### Проверка на простое число (Kotlin) | prime простое число is_prime простые sieve решето kotlin Kotlin | Kotlin
```kotlin
fun isPrime(n: Int): Boolean {
    if (n < 2) return false
    var i = 2
    while (i.toLong() * i <= n) { if (n % i == 0) return false; i++ }
    return true
}
```

### Разворот строки (Kotlin) | reverse string развернуть строку reverse перевернуть kotlin Kotlin | Kotlin
```kotlin
fun reverse(s: String) = s.reversed()
```

### Палиндром (Kotlin) | palindrome палиндром проверка строка kotlin Kotlin | Kotlin
```kotlin
fun isPalindrome(s: String): Boolean {
    val t = s.filter { it.isLetterOrDigit() }.lowercase()
    return t == t.reversed()
}
```

### Наибольший общий делитель (НОД) (Kotlin) | gcd нод greatest common divisor euclid евклид kotlin Kotlin | Kotlin
```kotlin
tailrec fun gcd(a: Long, b: Long): Long = if (b == 0L) a else gcd(b, a % b)
```

### Подсчёт слов в тексте (Kotlin) | count words частота слов word frequency hashmap словарь dictionary kotlin Kotlin | Kotlin
```kotlin
fun wordFreq(text: String) =
    Regex("[\\p{L}\\p{N}]+").findAll(text.lowercase())
        .map { it.value }
        .groupingBy { it }.eachCount()
        .toList().sortedByDescending { it.second }
```

### Чтение файла построчно (Kotlin) | read file чтение файла построчно file io open kotlin Kotlin | Kotlin
```kotlin
java.io.File("data.txt").forEachLine { println(it) }
```

### HTTP GET запрос (Kotlin) | http get запрос request fetch api rest json kotlin Kotlin | Kotlin
```kotlin
// Без библиотек
val c = URL("https://api.example.com/items").openConnection() as HttpURLConnection
val text = c.inputStream.bufferedReader().readText()
// Запускать НЕ в главном потоке: withContext(Dispatchers.IO) { ... }
```

### Разбор JSON (Kotlin) | json parse разбор json serialize сериализация десериализация kotlin Kotlin | Kotlin
```kotlin
// kotlinx.serialization
@Serializable data class Item(val a: Int, val b: List<Int>)
val item = Json.decodeFromString<Item>("""{"a":1,"b":[1,2]}""")
val text = Json.encodeToString(item)
```

### FizzBuzz (Kotlin) | fizzbuzz физзбазз loops циклы условия kotlin Kotlin | Kotlin
```kotlin
for (i in 1..100) println(when {
    i % 15 == 0 -> "FizzBuzz"
    i % 3 == 0 -> "Fizz"
    i % 5 == 0 -> "Buzz"
    else -> i
})
```

### Класс и наследование (Kotlin) | class inheritance класс наследование ооп oop interface интерфейс kotlin Kotlin | Kotlin
```kotlin
abstract class Animal(val name: String) {
    abstract fun speak(): String
}
class Dog(name: String) : Animal(name) {
    override fun speak() = "$name: Гав!"
}
```

### Обработка ошибок (Kotlin) | error handling exceptions обработка ошибок исключения try catch kotlin Kotlin | Kotlin
```kotlin
val n = runCatching { text.toInt() }.getOrElse { 0 }

try { risky() }
catch (e: IllegalStateException) { println(e.message) }
finally { println("всегда") }
```

### Потоки и параллелизм (Kotlin) | thread async parallel потоки асинхронность concurrency корутины coroutine kotlin Kotlin | Kotlin
```kotlin
runBlocking {
    val r = (1..5).map { i -> async { delay(1000); i * 2 } }.awaitAll()
    println(r)
}
```
