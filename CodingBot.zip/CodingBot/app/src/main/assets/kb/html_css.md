### HTML: каркас страницы | html шаблон каркас страницы разметка doctype | HTML
```html
<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Страница</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header><nav>...</nav></header>
  <main><h1>Заголовок</h1></main>
  <footer>© 2026</footer>
  <script src="app.js" defer></script>
</body>
</html>
```

### CSS: Flexbox | css flexbox flex выравнивание строка колонка | CSS
```css
.row { display: flex; gap: 12px; justify-content: space-between; align-items: center; flex-wrap: wrap; }
.grow { flex: 1; }
```
`justify-content`: главная ось, `align-items`: поперечная.

### CSS: Grid | css grid сетка колонки layout | CSS
```css
.grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; }
```

### CSS: адаптивность | css responsive media query адаптив мобильный | CSS
```css
.card { padding: 24px; }
@media (max-width: 600px) {
  .card { padding: 12px; }
}
img { max-width: 100%; height: auto; }
```

### CSS: переменные и тёмная тема | css variables dark mode тёмная тема custom properties | CSS
```css
:root { --bg: #fff; --fg: #111; }
@media (prefers-color-scheme: dark) { :root { --bg: #111; --fg: #eee; } }
body { background: var(--bg); color: var(--fg); }
```

### CSS: анимации | css animation transition анимация переход keyframes | CSS
```css
.btn { transition: transform .2s, background .2s; }
.btn:hover { transform: translateY(-2px); }
@keyframes spin { to { transform: rotate(360deg); } }
.loader { animation: spin 1s linear infinite; }
```

### CSS: box-sizing и отступы | css box-sizing margin padding box model отступы | CSS
```css
*, *::before, *::after { box-sizing: border-box; }
```
Тогда `width` включает padding и border, и вёрстка предсказуема.

### HTML: форма | html form input форма валидация | HTML
```html
<form method="post" action="/send">
  <label>Email <input type="email" name="email" required></label>
  <input type="password" name="pw" minlength="8" required>
  <button type="submit">Отправить</button>
</form>
```
Валидацию всегда дублируй на сервере.
