### Бинарный поиск (JavaScript) | binary search бинарный поиск sorted array отсортированный массив O(log n) javascript JavaScript | JavaScript
```javascript
function binarySearch(a, x) {
  let lo = 0, hi = a.length - 1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (a[mid] === x) return mid;
    if (a[mid] < x) lo = mid + 1; else hi = mid - 1;
  }
  return -1;
}
```

### Быстрая сортировка (JavaScript) | quicksort быстрая сортировка sort сортировка алгоритм O(n log n) javascript JavaScript | JavaScript
```javascript
function quicksort(a) {
  if (a.length <= 1) return a;
  const p = a[a.length >> 1];
  return [
    ...quicksort(a.filter(x => x < p)),
    ...a.filter(x => x === p),
    ...quicksort(a.filter(x => x > p)),
  ];
}
```

### Сортировка слиянием (JavaScript) | merge sort сортировка слиянием sort алгоритм stable стабильная javascript JavaScript | JavaScript
```javascript
function mergeSort(a) {
  if (a.length <= 1) return a;
  const m = a.length >> 1;
  const l = mergeSort(a.slice(0, m)), r = mergeSort(a.slice(m));
  const out = [];
  let i = 0, j = 0;
  while (i < l.length && j < r.length) out.push(l[i] <= r[j] ? l[i++] : r[j++]);
  return out.concat(l.slice(i), r.slice(j));
}
```

### Числа Фибоначчи (JavaScript) | fibonacci фибоначчи число recursion рекурсия итерация javascript JavaScript | JavaScript
```javascript
function fib(n) {
  let a = 0n, b = 1n;
  for (let i = 0; i < n; i++) [a, b] = [b, a + b];
  return a; // BigInt, не переполняется
}
```

### Проверка на простое число (JavaScript) | prime простое число is_prime простые sieve решето javascript JavaScript | JavaScript
```javascript
function isPrime(n) {
  if (n < 2) return false;
  for (let i = 2; i * i <= n; i++) if (n % i === 0) return false;
  return true;
}
```

### Разворот строки (JavaScript) | reverse string развернуть строку reverse перевернуть javascript JavaScript | JavaScript
```javascript
const reverse = s => [...s].reverse().join('');
```

### Палиндром (JavaScript) | palindrome палиндром проверка строка javascript JavaScript | JavaScript
```javascript
const isPalindrome = s => {
  const t = s.toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');
  return t === [...t].reverse().join('');
};
```

### Наибольший общий делитель (НОД) (JavaScript) | gcd нод greatest common divisor euclid евклид javascript JavaScript | JavaScript
```javascript
const gcd = (a, b) => (b === 0 ? a : gcd(b, a % b));
```

### Подсчёт слов в тексте (JavaScript) | count words частота слов word frequency hashmap словарь dictionary javascript JavaScript | JavaScript
```javascript
function wordFreq(text) {
  const m = new Map();
  for (const w of text.toLowerCase().match(/[\p{L}\p{N}]+/gu) ?? [])
    m.set(w, (m.get(w) ?? 0) + 1);
  return [...m].sort((a, b) => b[1] - a[1]);
}
```

### Чтение файла построчно (JavaScript) | read file чтение файла построчно file io open javascript JavaScript | JavaScript
```javascript
// Node.js
import { createReadStream } from 'node:fs';
import readline from 'node:readline';

const rl = readline.createInterface({ input: createReadStream('data.txt') });
for await (const line of rl) console.log(line);
```

### HTTP GET запрос (JavaScript) | http get запрос request fetch api rest json javascript JavaScript | JavaScript
```javascript
const res = await fetch('https://api.example.com/items?q=x');
if (!res.ok) throw new Error(res.status);
const data = await res.json();
```

### Разбор JSON (JavaScript) | json parse разбор json serialize сериализация десериализация javascript JavaScript | JavaScript
```javascript
const obj = JSON.parse('{"a":1,"b":[1,2]}');
const text = JSON.stringify(obj, null, 2);
```

### FizzBuzz (JavaScript) | fizzbuzz физзбазз loops циклы условия javascript JavaScript | JavaScript
```javascript
for (let i = 1; i <= 100; i++)
  console.log(i % 15 === 0 ? 'FizzBuzz' : i % 3 === 0 ? 'Fizz' : i % 5 === 0 ? 'Buzz' : i);
```

### Класс и наследование (JavaScript) | class inheritance класс наследование ооп oop interface интерфейс javascript JavaScript | JavaScript
```javascript
class Animal {
  constructor(name) { this.name = name; }
  speak() { throw new Error('not implemented'); }
}
class Dog extends Animal {
  speak() { return `${this.name}: Гав!`; }
}
```

### Обработка ошибок (JavaScript) | error handling exceptions обработка ошибок исключения try catch javascript JavaScript | JavaScript
```javascript
try {
  JSON.parse(text);
} catch (e) {
  console.error('ошибка:', e.message);
} finally {
  console.log('всегда');
}
```

### Потоки и параллелизм (JavaScript) | thread async parallel потоки асинхронность concurrency корутины coroutine javascript JavaScript | JavaScript
```javascript
const sleep = ms => new Promise(r => setTimeout(r, ms));
const results = await Promise.all([1, 2, 3].map(async i => { await sleep(100); return i * 2; }));
```
