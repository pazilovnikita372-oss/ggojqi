### Регулярные выражения: шпаргалка | regex регулярные выражения шпаргалка regexp синтаксис | Regex
```
.      любой символ        \d  цифра        \w  буква/цифра/_
\s     пробел              \b  граница слова
^ $    начало/конец        *   0+           +   1+        ?  0 или 1
{n,m}  от n до m           [abc] набор      [^abc] кроме
(...)  группа              (?:...) без захвата   a|b  или
(?=...) lookahead          (?<=...) lookbehind
```
Жадность: `.*` берёт максимум, `.*?` минимум.

### Regex: email | regex email почта проверка валидация | Regex
```
^[\w.+-]+@[\w-]+(\.[\w-]+)+$
```
Это упрощённая проверка. Единственная надёжная проверка адреса: отправить письмо со ссылкой.

### Regex: телефон | regex phone телефон номер россия | Regex
```
^(\+7|8)[\s-]?\(?\d{3}\)?[\s-]?\d{3}[\s-]?\d{2}[\s-]?\d{2}$
```

### Regex: URL | regex url ссылка http https | Regex
```
https?://[\w.-]+(?:/[\w./?%&=#+-]*)?
```

### Regex: дата | regex date дата дд.мм.гггг yyyy-mm-dd | Regex
```
\d{4}-\d{2}-\d{2}              # 2026-10-09
(0[1-9]|[12]\d|3[01])\.(0[1-9]|1[0-2])\.\d{4}   # 09.10.2026
```
Формат проверит, но не поймает 31.02. Для этого парси дату библиотекой.

### Regex: пароль | regex password пароль сложность lookahead | Regex
```
^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$
```
Минимум 8 символов, строчная, заглавная и цифра.

### Regex в Python | python re regex findall sub match search | Python
```python
import re
re.findall(r"\d+", "a1b22c333")           # ['1','22','333']
re.sub(r"\s+", " ", "a   b \n c")          # 'a b c'
m = re.search(r"(?P<y>\d{4})-(?P<m>\d\d)", "2026-10")
m.group("y")                               # '2026'
```

### Regex в JavaScript | javascript regex match replace test регулярки js | JavaScript
```javascript
/\d+/g.test("a1");                   // true
"a1b22".match(/\d+/g);               // ['1','22']
"2026-10".replace(/(\d+)-(\d+)/, "$2.$1");
for (const m of "a1b2".matchAll(/[a-z](\d)/g)) console.log(m[1]);
```
