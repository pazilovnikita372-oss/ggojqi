### Git: отменить последний коммит | git undo commit отменить коммит reset revert откат | Git
Оставить изменения в файлах:
```bash
git reset --soft HEAD~1
```
Убрать коммит и изменения совсем (необратимо):
```bash
git reset --hard HEAD~1
```
Если коммит уже запушен, безопаснее создать обратный коммит:
```bash
git revert HEAD
```

### Git: изменить сообщение последнего коммита | git amend commit message изменить сообщение | Git
```bash
git commit --amend -m "новое сообщение"
```
Не делай этого для уже запушенных коммитов в общей ветке.

### Git: создать ветку и переключиться | git branch checkout switch ветка | Git
```bash
git switch -c feature/login     # новая ветка
git switch main                 # вернуться
git branch -d feature/login     # удалить после слияния
```

### Git: слияние и rebase | git merge rebase слияние ветки | Git
```bash
git switch main
git merge feature/login          # merge-коммит
git switch feature/login
git rebase main                  # перенести коммиты поверх main
```
Rebase переписывает историю: не используй на опубликованных ветках.

### Git: конфликт слияния | git merge conflict конфликт разрешить | Git
1. `git status` покажет конфликтные файлы.
2. Открой файл, найди маркеры `<<<<<<<`, `=======`, `>>>>>>>`, оставь нужный код и удали маркеры.
3. Заверши:
```bash
git add файл
git commit            # при merge
git rebase --continue # при rebase
```
Отменить слияние: `git merge --abort`.

### Git: stash, спрятать изменения | git stash спрятать изменения временно | Git
```bash
git stash push -m "wip"
git stash list
git stash pop        # вернуть и удалить
git stash apply      # вернуть и оставить
```

### Git: посмотреть историю | git log history история diff | Git
```bash
git log --oneline --graph --decorate --all
git log -p файл            # изменения файла
git diff                   # не добавленные изменения
git diff --staged          # добавленные
git blame файл             # кто менял строки
```

### Git: удалить файл из индекса и .gitignore | git gitignore rm cached игнорировать файл | Git
```bash
echo "build/" >> .gitignore
git rm -r --cached build/
git commit -m "stop tracking build"
```

### Git: cherry-pick | git cherry-pick перенести коммит | Git
```bash
git cherry-pick <hash>
```

### Git: удалить секрет из истории | git secret password удалить пароль из истории filter-repo | Git
Если в репозиторий попал ключ, сначала **отзови ключ** у сервиса: он уже скомпрометирован. Потом чисти историю:
```bash
pip install git-filter-repo
git filter-repo --path secrets.txt --invert-paths
git push --force
```

### Git: настройка | git config user name email настройка | Git
```bash
git config --global user.name "Имя"
git config --global user.email "me@example.com"
git config --global init.defaultBranch main
```

### Git: подключить удалённый репозиторий | git remote push origin github | Git
```bash
git remote add origin https://github.com/user/repo.git
git push -u origin main
git pull --rebase
```
