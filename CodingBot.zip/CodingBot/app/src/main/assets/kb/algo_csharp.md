### Бинарный поиск (C#) | binary search бинарный поиск sorted array отсортированный массив O(log n) csharp C# | C#
```csharp
static int BinarySearch(int[] a, int x)
{
    int lo = 0, hi = a.Length - 1;
    while (lo <= hi)
    {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] == x) return mid;
        if (a[mid] < x) lo = mid + 1; else hi = mid - 1;
    }
    return -1;
}
```

### Быстрая сортировка (C#) | quicksort быстрая сортировка sort сортировка алгоритм O(n log n) csharp C# | C#
```csharp
static List<int> Quicksort(List<int> a)
{
    if (a.Count <= 1) return a;
    int p = a[a.Count / 2];
    var res = Quicksort(a.Where(x => x < p).ToList());
    res.AddRange(a.Where(x => x == p));
    res.AddRange(Quicksort(a.Where(x => x > p).ToList()));
    return res;
}
```

### Сортировка слиянием (C#) | merge sort сортировка слиянием sort алгоритм stable стабильная csharp C# | C#
```csharp
static int[] MergeSort(int[] a)
{
    if (a.Length <= 1) return a;
    int m = a.Length / 2;
    var l = MergeSort(a[..m]);
    var r = MergeSort(a[m..]);
    var o = new int[a.Length];
    int i = 0, j = 0, k = 0;
    while (i < l.Length && j < r.Length) o[k++] = l[i] <= r[j] ? l[i++] : r[j++];
    while (i < l.Length) o[k++] = l[i++];
    while (j < r.Length) o[k++] = r[j++];
    return o;
}
```

### Числа Фибоначчи (C#) | fibonacci фибоначчи число recursion рекурсия итерация csharp C# | C#
```csharp
static ulong Fib(int n)
{
    ulong a = 0, b = 1;
    for (int i = 0; i < n; i++) { var t = a + b; a = b; b = t; }
    return a;
}
```

### Проверка на простое число (C#) | prime простое число is_prime простые sieve решето csharp C# | C#
```csharp
static bool IsPrime(int n)
{
    if (n < 2) return false;
    for (long i = 2; i * i <= n; i++) if (n % i == 0) return false;
    return true;
}
```

### Разворот строки (C#) | reverse string развернуть строку reverse перевернуть csharp C# | C#
```csharp
static string Reverse(string s)
{
    var c = s.ToCharArray();
    Array.Reverse(c);
    return new string(c);
}
```

### Палиндром (C#) | palindrome палиндром проверка строка csharp C# | C#
```csharp
static bool IsPalindrome(string s)
{
    var t = new string(s.Where(char.IsLetterOrDigit).Select(char.ToLower).ToArray());
    return t.SequenceEqual(t.Reverse());
}
```

### Наибольший общий делитель (НОД) (C#) | gcd нод greatest common divisor euclid евклид csharp C# | C#
```csharp
using System.Numerics;
var g = BigInteger.GreatestCommonDivisor(48, 18);

static long Gcd(long a, long b) => b == 0 ? a : Gcd(b, a % b);
```

### Подсчёт слов в тексте (C#) | count words частота слов word frequency hashmap словарь dictionary csharp C# | C#
```csharp
static Dictionary<string, int> WordFreq(string text) =>
    Regex.Matches(text.ToLower(), @"[\p{L}\p{N}]+")
         .GroupBy(m => m.Value)
         .ToDictionary(g => g.Key, g => g.Count());
```

### Чтение файла построчно (C#) | read file чтение файла построчно file io open csharp C# | C#
```csharp
foreach (var line in File.ReadLines("data.txt"))
    Console.WriteLine(line);
```

### HTTP GET запрос (C#) | http get запрос request fetch api rest json csharp C# | C#
```csharp
using var http = new HttpClient();
string text = await http.GetStringAsync("https://api.example.com/items");
```

### Разбор JSON (C#) | json parse разбор json serialize сериализация десериализация csharp C# | C#
```csharp
var obj = JsonSerializer.Deserialize<Dictionary<string, object>>(json);
string text = JsonSerializer.Serialize(obj, new JsonSerializerOptions { WriteIndented = true });
```

### FizzBuzz (C#) | fizzbuzz физзбазз loops циклы условия csharp C# | C#
```csharp
for (int i = 1; i <= 100; i++)
    Console.WriteLine(i % 15 == 0 ? "FizzBuzz" : i % 3 == 0 ? "Fizz" : i % 5 == 0 ? "Buzz" : i.ToString());
```

### Класс и наследование (C#) | class inheritance класс наследование ооп oop interface интерфейс csharp C# | C#
```csharp
abstract class Animal(string name)
{
    protected string Name => name;
    public abstract string Speak();
}
class Dog(string name) : Animal(name)
{
    public override string Speak() => $"{Name}: Гав!";
}
```

### Обработка ошибок (C#) | error handling exceptions обработка ошибок исключения try catch csharp C# | C#
```csharp
try { int x = int.Parse(text); }
catch (FormatException e) { Console.Error.WriteLine(e.Message); }
finally { Console.WriteLine("всегда"); }
```

### Потоки и параллелизм (C#) | thread async parallel потоки асинхронность concurrency корутины coroutine csharp C# | C#
```csharp
var tasks = Enumerable.Range(0, 5).Select(async i => { await Task.Delay(100); return i * 2; });
var res = await Task.WhenAll(tasks);
```
