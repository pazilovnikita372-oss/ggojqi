### JavaScript: массивы map filter reduce | javascript array map filter reduce массивы методы | JavaScript
```javascript
const nums = [1, 2, 3, 4];
nums.map(x => x * 2);                // [2,4,6,8]
nums.filter(x => x % 2 === 0);       // [2,4]
nums.reduce((s, x) => s + x, 0);     // 10
nums.find(x => x > 2);               // 3
nums.some(x => x > 3); nums.every(x => x > 0);
[...nums, 5]; nums.slice(1, 3); nums.flat();
```

### JavaScript: деструктуризация и spread | javascript destructuring spread деструктуризация rest | JavaScript
```javascript
const { a, b = 1, ...rest } = obj;
const [first, , third] = arr;
const merged = { ...defaults, ...options };
function f(...args) {}
```

### JavaScript: Promise и async | javascript promise async await then асинхронный | JavaScript
```javascript
const [a, b] = await Promise.all([fetchA(), fetchB()]);
const first = await Promise.race([p1, p2]);
const r = await Promise.allSettled([p1, p2]);   // не падает при ошибке одного
```

### JavaScript: DOM | javascript dom querySelector addEventListener html элементы события | JavaScript
```javascript
const btn = document.querySelector("#btn");
btn.addEventListener("click", e => {
  document.querySelector(".out").textContent = "нажато";
});
document.querySelectorAll(".item").forEach(el => el.classList.toggle("active"));
```
Для текста используй `textContent`, а не `innerHTML` (защита от XSS).

### JavaScript: localStorage | javascript localstorage хранение браузер storage сохранить | JavaScript
```javascript
localStorage.setItem("cfg", JSON.stringify({ theme: "dark" }));
const cfg = JSON.parse(localStorage.getItem("cfg") ?? "{}");
```

### JavaScript: модули | javascript import export module модули esm commonjs | JavaScript
```javascript
// math.js
export const sum = (a, b) => a + b;
export default function main() {}
// app.js
import main, { sum } from "./math.js";
```
В Node.js: `"type": "module"` в package.json или расширение `.mjs`.

### Node.js: простой сервер Express | nodejs node express сервер api бэкенд | JavaScript
```javascript
import express from "express";
const app = express();
app.use(express.json());
app.get("/api/hi", (req, res) => res.json({ hi: req.query.name ?? "мир" }));
app.listen(3000);
```

### React: компонент и состояние | react usestate useeffect компонент хуки hooks | JavaScript
```jsx
import { useState, useEffect } from "react";

export function Counter() {
  const [n, setN] = useState(0);
  useEffect(() => { document.title = `n=${n}`; }, [n]);
  return <button onClick={() => setN(n + 1)}>Нажато {n}</button>;
}
```
Не меняй состояние напрямую: `setList([...list, x])`. Массив зависимостей `useEffect` должен содержать все используемые значения.

### TypeScript: основы | typescript ts типы interface type generic типизация | TypeScript
```typescript
interface User { id: number; name: string; email?: string }
type Id = string | number;
function first<T>(a: T[]): T | undefined { return a[0]; }
const u: Readonly<User> = { id: 1, name: "A" };
```

### JavaScript: даты | javascript date дата время intl форматирование | JavaScript
```javascript
const d = new Date();
d.toISOString();
new Intl.DateTimeFormat("ru-RU", { dateStyle: "long" }).format(d);
Date.now() - start;   // мс
```

### JavaScript: debounce | javascript debounce throttle задержка поиск оптимизация | JavaScript
```javascript
function debounce(fn, ms = 300) {
  let t;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}
input.addEventListener("input", debounce(search, 300));
```
