### Java: коллекции | java collections list map set arraylist hashmap коллекции | Java
```java
List<Integer> list = new ArrayList<>(List.of(3, 1, 2));
Collections.sort(list);
Map<String, Integer> m = new HashMap<>();
m.merge("a", 1, Integer::sum);
Set<String> s = new TreeSet<>();
```

### Java: Stream API | java stream api filter map collect потоки | Java
```java
List<String> names = users.stream()
    .filter(u -> u.age() >= 18)
    .map(User::name)
    .sorted()
    .collect(Collectors.toList());
int sum = nums.stream().mapToInt(Integer::intValue).sum();
```

### Java: record, enum, switch | java record enum switch expression современный java 17 | Java
```java
record Point(int x, int y) {}
enum Color { RED, GREEN }
String s = switch (color) {
    case RED -> "красный";
    case GREEN -> "зелёный";
};
```

### Java: Spring Boot REST | java spring boot rest controller api сервер | Java
```java
@RestController
@RequestMapping("/api/users")
class UserController {
    @GetMapping("/{id}")
    User get(@PathVariable long id) { return service.find(id); }
    @PostMapping
    ResponseEntity<User> create(@RequestBody @Valid User u) {
        return ResponseEntity.status(201).body(service.save(u));
    }
}
```

### C++: STL контейнеры | cpp c++ stl vector map set контейнеры | C++
```cpp
std::vector<int> v{3, 1, 2};
std::sort(v.begin(), v.end());
std::unordered_map<std::string, int> m; m["a"]++;
std::set<int> s{1, 2}; s.count(1);
for (auto& [k, val] : m) std::cout << k << val;
```

### C++: умные указатели | cpp c++ smart pointer unique_ptr shared_ptr указатели память raii | C++
```cpp
auto p = std::make_unique<Foo>(1);        // единственный владелец
auto q = std::make_shared<Foo>(2);        // общий
// delete вручную не нужен: RAII освободит память
```
Избегай голых `new/delete`. `weak_ptr` разрывает циклы `shared_ptr`.

### C++: чтение ввода | cpp c++ cin getline ввод input | C++
```cpp
std::ios::sync_with_stdio(false); std::cin.tie(nullptr);
int n; std::cin >> n;
std::string line; std::getline(std::cin >> std::ws, line);
```

### Go: структуры и методы | go golang struct method интерфейс структуры | Go
```go
type User struct {
	ID   int    `json:"id"`
	Name string `json:"name"`
}
func (u *User) Rename(n string) { u.Name = n }
```

### Go: HTTP-сервер | go golang http server сервер api net/http | Go
```go
http.HandleFunc("/hi", func(w http.ResponseWriter, r *http.Request) {
	json.NewEncoder(w).Encode(map[string]string{"hi": r.URL.Query().Get("name")})
})
log.Fatal(http.ListenAndServe(":8080", nil))
```

### Go: горутины и каналы | go golang goroutine channel select горутины каналы | Go
```go
ch := make(chan int)
go func() { for i := 0; i < 3; i++ { ch <- i }; close(ch) }()
for v := range ch { fmt.Println(v) }

select {
case v := <-ch:
	_ = v
case <-time.After(time.Second):
	fmt.Println("таймаут")
}
```

### Rust: Option и Result | rust option result unwrap match ошибки оператор ? | Rust
```rust
fn read(p: &str) -> Result<String, std::io::Error> {
    let s = std::fs::read_to_string(p)?;   // ? пробрасывает ошибку
    Ok(s.trim().to_string())
}
let n = opt.unwrap_or(0);
if let Some(x) = opt { println!("{x}"); }
```

### Rust: структуры, трейты | rust struct trait impl derive структуры трейты | Rust
```rust
#[derive(Debug, Clone, PartialEq)]
struct P { x: i32, y: i32 }
impl P { fn len2(&self) -> i32 { self.x * self.x + self.y * self.y } }
```

### C#: LINQ | csharp c# linq where select группировка | C#
```csharp
var adults = people.Where(p => p.Age >= 18).OrderBy(p => p.Name).Select(p => p.Name).ToList();
var byCity = people.GroupBy(p => p.City).ToDictionary(g => g.Key, g => g.Count());
```

### C#: ASP.NET Minimal API | csharp c# aspnet minimal api сервер web | C#
```csharp
var app = WebApplication.CreateBuilder(args).Build();
app.MapGet("/hi", (string? name) => Results.Ok(new { hi = name ?? "мир" }));
app.Run();
```

### PHP: основы и PDO | php основы pdo mysql запрос веб | PHP
```php
<?php
$pdo = new PDO("mysql:host=localhost;dbname=app", "user", "pass");
$st = $pdo->prepare("SELECT * FROM users WHERE email = ?");
$st->execute([$email]);
$rows = $st->fetchAll(PDO::FETCH_ASSOC);
echo htmlspecialchars($rows[0]["name"] ?? "");
```

### Swift: основы | swift ios основы optional struct протокол | Swift
```swift
struct User { let id: Int; var name: String }
var u: User? = User(id: 1, name: "A")
if let user = u { print(user.name) }
let ys = [1, 2, 3].map { $0 * 2 }
```
