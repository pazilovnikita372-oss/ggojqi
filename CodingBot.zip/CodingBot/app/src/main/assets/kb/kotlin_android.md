### Kotlin: основы | kotlin основы val var null safety синтаксис | Kotlin
```kotlin
val x = 5            // неизменяемая
var y = "a"          // изменяемая
val s: String? = null
val n = s?.length ?: 0          // безопасный вызов + значение по умолчанию
s!!.length                      // бросит NPE, избегай
when (x) { 1 -> "one"; in 2..5 -> "few"; else -> "many" }
```

### Kotlin: коллекции | kotlin list map filter collections коллекции лямбды | Kotlin
```kotlin
val xs = listOf(1, 2, 3, 4)
xs.filter { it % 2 == 0 }.map { it * it }.sum()
xs.groupBy { it % 2 }
xs.associateWith { it * 2 }
val m = mutableMapOf("a" to 1); m["b"] = 2
xs.sortedByDescending { it }
```

### Kotlin: data class и sealed class | kotlin data class sealed class sealed interface | Kotlin
```kotlin
data class User(val id: Int, val name: String)
val u2 = User(1, "A").copy(name = "B")

sealed interface Result {
    data class Ok(val v: Int) : Result
    data class Err(val e: String) : Result
}
fun show(r: Result) = when (r) {
    is Result.Ok -> "ok ${r.v}"
    is Result.Err -> "err ${r.e}"
}
```

### Kotlin: корутины | kotlin coroutines корутины launch async suspend flow | Kotlin
```kotlin
suspend fun load(): String = withContext(Dispatchers.IO) { URL(u).readText() }

viewModelScope.launch {
    val (a, b) = coroutineScope {
        val x = async { api1() }
        val y = async { api2() }
        x.await() to y.await()
    }
}

fun ticks() = flow { var i = 0; while (true) { emit(i++); delay(1000) } }
```

### Android: Jetpack Compose основы | android compose jetpack composable ui экран интерфейс | Android
```kotlin
@Composable
fun Counter() {
    var n by remember { mutableStateOf(0) }
    Column(Modifier.padding(16.dp)) {
        Text("Нажато: $n")
        Button(onClick = { n++ }) { Text("+1") }
    }
}
```
Состояние в `remember`/`ViewModel`, UI перерисовывается при изменении.

### Android: список LazyColumn | android lazycolumn список compose recycler | Android
```kotlin
LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
    items(users, key = { it.id }) { u -> Text(u.name) }
}
```

### Android: ViewModel и StateFlow | android viewmodel stateflow mvvm архитектура | Android
```kotlin
class VM : ViewModel() {
    private val _ui = MutableStateFlow(UiState())
    val ui = _ui.asStateFlow()
    fun load() = viewModelScope.launch {
        _ui.update { it.copy(loading = true) }
        val data = repo.get()
        _ui.update { it.copy(loading = false, items = data) }
    }
}
// в Compose: val s by vm.ui.collectAsState()
```

### Android: навигация Compose | android navigation compose навигация экраны navhost | Android
```kotlin
val nav = rememberNavController()
NavHost(nav, startDestination = "list") {
    composable("list") { ListScreen(onOpen = { nav.navigate("detail/$it") }) }
    composable("detail/{id}") { e -> Detail(e.arguments?.getString("id")) }
}
```
Зависимость: `androidx.navigation:navigation-compose`.

### Android: разрешения | android permission разрешения runtime камера геолокация | Android
```xml
<uses-permission android:name="android.permission.CAMERA"/>
```
```kotlin
val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> }
launcher.launch(Manifest.permission.CAMERA)
```

### Android: SharedPreferences и DataStore | android sharedpreferences datastore настройки хранение | Android
```kotlin
val p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
p.edit().putString("k", "v").apply()
val v = p.getString("k", "")
```
Для нового кода лучше `DataStore`. Секреты (ключи API) хранить в `EncryptedSharedPreferences`.

### Android: подписать release APK | android signing release keystore apk подпись публикация | Android
```bash
keytool -genkey -v -keystore my.jks -keyalg RSA -keysize 2048 -validity 10000 -alias key
./gradlew assembleRelease
```
Прописать `signingConfigs` в `build.gradle.kts` и хранить keystore и пароли вне репозитория.

### Android: GitHub Actions сборка APK | android github actions ci apk сборка workflow | Android
```yaml
name: Build APK
on: [push, workflow_dispatch]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with: { distribution: temurin, java-version: 17 }
      - run: gradle assembleDebug --no-daemon
      - uses: actions/upload-artifact@v4
        with: { name: app-debug, path: app/build/outputs/apk/debug/app-debug.apk }
```

### Android: Retrofit | android retrofit okhttp сеть api http клиент | Android
```kotlin
interface Api { @GET("users/{id}") suspend fun user(@Path("id") id: Int): User }
val api = Retrofit.Builder().baseUrl("https://api.example.com/")
    .addConverterFactory(MoshiConverterFactory.create()).build().create(Api::class.java)
```
