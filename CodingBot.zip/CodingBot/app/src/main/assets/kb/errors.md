### Python: IndentationError | python indentationerror отступ ошибка unexpected indent | Python
Python использует отступы как структуру. Причины: смесь табов и пробелов или лишний/недостающий отступ. Используй 4 пробела везде; в редакторе включи показ пробелов; `python -m tabnanny файл.py` найдёт смешение.

### Python: ModuleNotFoundError | python modulenotfounderror no module named import pip модуль не найден | Python
```bash
python -m pip install имя_пакета      # ставит в тот же python, что и запускает
python -m venv .venv && source .venv/bin/activate
```
Имя в pip может отличаться от имени импорта (`pip install pillow` → `import PIL`). Если файл называется как модуль (`random.py`), он перекрывает стандартный.

### Python: TypeError NoneType | python typeerror nonetype not subscriptable none ошибка | Python
Функция вернула `None` (часто забыт `return`, или метод вроде `list.sort()` меняет на месте и возвращает None). Проверь значение до использования:
```python
if result is not None:
    ...
```

### Python: KeyError и IndexError | python keyerror indexerror ключ индекс словарь список | Python
```python
d.get("key", default)        # вместо d["key"]
if i < len(lst): lst[i]
```

### Python: изменяемый аргумент по умолчанию | python mutable default argument аргумент по умолчанию список баг | Python
Ловушка:
```python
def add(x, acc=[]):     # один список на все вызовы!
    acc.append(x); return acc
```
Правильно:
```python
def add(x, acc=None):
    acc = [] if acc is None else acc
    acc.append(x); return acc
```

### JavaScript: undefined is not a function / Cannot read properties of undefined | javascript undefined cannot read properties null ошибка | JavaScript
Обращение к полю у `undefined`/`null`. Проверь данные и используй безопасный доступ:
```javascript
const city = user?.address?.city ?? "неизвестно";
```
Если данные приходят асинхронно, проверь, что они уже загрузились (`await`).

### JavaScript: this теряется | javascript this arrow bind контекст this потерян | JavaScript
```javascript
class A {
  x = 1;
  ok = () => this.x;        // стрелка запоминает this
  bad() { return this.x; }  // при передаче как callback this потеряется
}
const f = new A().bad.bind(a);
```

### JavaScript: == против === | javascript equality сравнение == === типы | JavaScript
Используй `===`. `==` приводит типы: `0 == ""` true, `null == undefined` true. NaN не равен себе: `Number.isNaN(x)`.

### JavaScript: async/await ошибки | javascript async await promise unhandled rejection промис | JavaScript
```javascript
async function load() {
  try {
    const r = await fetch(url);
    if (!r.ok) throw new Error(r.status);
    return await r.json();
  } catch (e) { console.error(e); }
}
```
Забытый `await` даёт `Promise` вместо значения. В цикле `forEach(async ...)` не ждёт: используй `for...of` или `Promise.all`.

### Java: NullPointerException | java nullpointerexception npe null ошибка | Java
Обращение к `null`. Смотри stack trace: первая строка твоего кода. Профилактика: `Objects.requireNonNull`, `Optional`, проверки входов.

### Java: ClassNotFoundException / NoClassDefFoundError | java classnotfound noclassdeffound classpath зависимость | Java
Библиотеки нет в classpath. Maven/Gradle: проверь зависимость и пересинхронизируй проект. Конфликт версий: `./gradlew dependencies`.

### Kotlin: lateinit property not initialized | kotlin lateinit not initialized свойство инициализация | Kotlin
Обращение к `lateinit var` до присвоения. Проверка: `if (::x.isInitialized)`. Лучше инициализировать сразу или использовать `by lazy { ... }`.

### Kotlin: smart cast impossible | kotlin smart cast impossible null mutable property | Kotlin
Для изменяемого `var` компилятор не гарантирует, что значение не изменится. Скопируй в локальную `val`:
```kotlin
val n = name ?: return
println(n.length)
```

### Android: NetworkOnMainThreadException | android networkonmainthread сеть главный поток корутины | Android
Нельзя ходить в сеть в главном потоке:
```kotlin
lifecycleScope.launch {
    val text = withContext(Dispatchers.IO) { URL(u).readText() }
    textView.text = text
}
```
Не забудь `<uses-permission android:name="android.permission.INTERNET"/>`.

### Android: приложение не устанавливается | android apk install parse error установка не установлено | Android
- Включи установку из неизвестных источников для браузера/файлового менеджера.
- Если уже стоит версия с другой подписью, удали её и поставь заново.
- Если APK внутри ZIP, сначала распакуй.
- «Приложение не установлено»: проверь, что архитектура/версия Android подходят (minSdk).

### Gradle: сборка падает | gradle build failed ошибка сборки dependency sdk | Android
- Читай **первую** красную строку `What went wrong`.
- `Could not resolve ...`: нет интернета или неверная версия зависимости.
- `SDK location not found`: пропиши путь в `local.properties` (`sdk.dir=...`).
- Версии Kotlin и Compose compiler должны совпадать (таблица совместимости на developer.android.com).
- `./gradlew clean assembleDebug --stacktrace`

### C++: segmentation fault | cpp c++ segfault segmentation fault сегфолт указатель | C++
Обращение к недоступной памяти: выход за границы массива, висячий/нулевой указатель, переполнение стека рекурсией. Собери с `-g -fsanitize=address,undefined` и запусти: санитайзер покажет точную строку.

### C++: undefined reference | cpp linker undefined reference линковка ошибка | C++
Функция объявлена, но не определена или не подключена библиотека. Добавь файл в сборку или `-lимя`. Шаблоны должны быть определены в заголовке.

### Rust: borrow checker | rust borrow checker borrowed moved ошибка владение ownership | Rust
- `value moved`: после передачи по значению переменная недоступна. Передай ссылку `&x` или `.clone()`.
- `cannot borrow as mutable`: нельзя одновременно `&mut` и другие ссылки. Сократи время жизни ссылок или раздели на блоки.
- Читай подсказки компилятора: обычно предлагают точный фикс.

### Go: nil pointer dereference | go golang nil pointer panic указатель | Go
Разыменование nil. Проверяй ошибки сразу (`if err != nil`), не используй результат при ошибке. Карту нужно инициализировать: `m := make(map[string]int)`.

### Git: failed to push / non-fast-forward | git push rejected non-fast-forward отклонён | Git
Удалённая ветка ушла вперёд. Сделай `git pull --rebase`, реши конфликты, затем `git push`. `--force` только если уверен, что перезапишешь свои же коммиты (`--force-with-lease` безопаснее).

### CSS: элемент не центрируется | css center центрировать flex grid выровнять | CSS
```css
.parent { display: flex; justify-content: center; align-items: center; }
/* или */
.parent { display: grid; place-items: center; }
```

### Общее: как правильно искать баг | debug отладка баг ошибка как искать debugging | Общее
1. Воспроизведи стабильно и сократи до минимального примера.
2. Прочитай ошибку целиком; первая строка стека в твоём коде.
3. Проверь предположения логами/отладчиком, не угадывай.
4. Дели пополам (закомментируй половину, `git bisect`).
5. Меняй одну вещь за раз.
