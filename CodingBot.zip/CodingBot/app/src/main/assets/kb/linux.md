### Linux: основные команды | linux bash команды ls cd cp mv rm mkdir терминал shell | Linux
```bash
ls -la            # список файлов
cd /путь          # перейти
pwd               # где я
cp -r a b         # копировать
mv a b            # переместить/переименовать
rm -r папка       # удалить (необратимо)
mkdir -p a/b/c    # создать вложенные
cat файл | less   # просмотр
```

### Linux: поиск файлов и текста | linux find grep поиск файлов текст ripgrep | Linux
```bash
find . -name "*.py" -mtime -7        # изменённые за неделю
grep -rn "TODO" --include="*.kt" .   # поиск по тексту
find . -type f -size +100M           # большие файлы
```

### Linux: права доступа chmod | linux chmod chown права permissions доступ | Linux
```bash
chmod +x script.sh      # сделать исполняемым
chmod 644 file          # rw-r--r--
chmod 755 dir           # rwxr-xr-x
chown user:group file
```
Цифры: 4 = чтение, 2 = запись, 1 = исполнение; три цифры для владельца, группы и остальных.

### Linux: процессы | linux ps kill top process процесс убить | Linux
```bash
ps aux | grep python
top / htop
kill PID            # вежливо
kill -9 PID         # принудительно
lsof -i :8080       # кто занял порт
```

### Linux: диск и память | linux df du free диск память место | Linux
```bash
df -h               # свободное место
du -sh * | sort -h  # размеры папок
free -h             # память
```

### Linux: pipes и перенаправление | linux pipe redirect пайп перенаправление stdout stderr | Linux
```bash
cmd > out.txt        # перезаписать
cmd >> out.txt       # дописать
cmd 2> err.txt       # только ошибки
cmd > all.txt 2>&1   # всё в один файл
cmd1 | cmd2          # вывод в ввод
```

### Linux: ssh и scp | linux ssh scp ключ подключение сервер | Linux
```bash
ssh-keygen -t ed25519
ssh user@host
scp file user@host:/path/
rsync -avz ./dir user@host:/path/
```

### Bash: скрипт, цикл, условия | bash script цикл условие if for while скрипт | Bash
```bash
#!/usr/bin/env bash
set -euo pipefail

for f in *.txt; do
  if [[ -s "$f" ]]; then
    echo "$f не пуст"
  fi
done
```

### Linux: curl | curl http запрос api curl post json | Linux
```bash
curl -s https://api.example.com/items
curl -X POST -H "Content-Type: application/json" \
     -d '{"name":"x"}' https://api.example.com/items
curl -L -o file.zip https://example.com/file.zip
```

### Linux: tar и zip | linux tar zip архив unzip распаковать | Linux
```bash
tar -czf a.tar.gz папка/    # создать
tar -xzf a.tar.gz           # распаковать
zip -r a.zip папка/
unzip a.zip
```

### Linux: cron | cron расписание задачи crontab | Linux
```bash
crontab -e
# минута час день месяц день_недели команда
0 3 * * * /home/me/backup.sh
*/15 * * * * /home/me/check.sh
```

### Linux: systemd сервис | systemd service systemctl сервис демон | Linux
```bash
systemctl status nginx
sudo systemctl restart nginx
sudo systemctl enable --now myapp
journalctl -u myapp -f
```
