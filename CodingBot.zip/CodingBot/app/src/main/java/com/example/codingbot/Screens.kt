@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.codingbot

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import java.util.UUID

fun fmt(s: String, codeColor: Color): AnnotatedString = buildAnnotatedString {
    val re = Regex("\\*\\*(.+?)\\*\\*|`([^`\\n]+)`")
    var i = 0
    for (m in re.findAll(s)) {
        append(s.substring(i, m.range.first))
        if (m.groupValues[1].isNotEmpty()) {
            withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(m.groupValues[1]) }
        } else {
            withStyle(SpanStyle(fontFamily = FontFamily.Monospace, color = codeColor)) { append(m.groupValues[2]) }
        }
        i = m.range.last + 1
    }
    append(s.substring(i))
}

@Composable
fun RichText(text: String) {
    val code = MaterialTheme.colorScheme.tertiary
    text.split("```").forEachIndexed { i, part ->
        if (i % 2 == 1) CodeBlock(part.substringAfter('\n', part).trimEnd())
        else if (part.isNotBlank()) SelectionContainer { Text(fmt(part.trim(), code), fontSize = 15.sp) }
    }
}

@Composable
fun CodeBlock(code: String) {
    val clipboard = LocalClipboardManager.current
    Column(
        Modifier.fillMaxWidth().padding(vertical = 6.dp)
            .background(Color.Black.copy(alpha = 0.35f), RoundedCornerShape(8.dp)).padding(8.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = { clipboard.setText(AnnotatedString(code)) }) { Text("Копировать") }
        }
        SelectionContainer {
            Text(
                code, fontFamily = FontFamily.Monospace, fontSize = 13.sp,
                color = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.horizontalScroll(rememberScrollState())
            )
        }
    }
}

@Composable
fun ChatScreen(store: Store, chat: ChatState, scope: CoroutineScope) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val prov = store.providers.firstOrNull { it.id == store.activeId }

    LaunchedEffect(chat.messages.size, chat.loading) {
        if (chat.messages.isNotEmpty()) listState.animateScrollToItem(chat.messages.size)
    }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f)) {
            if (chat.messages.isEmpty()) {
                EmptyState { chat.ask(scope, it) }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    items(chat.messages) { Bubble(it) }
                    item { if (chat.loading) Text("Думаю…", modifier = Modifier.padding(8.dp)) }
                }
            }
        }
        Text(
            if (prov == null) "Режим: офлайн-база знаний" else "Режим: ${prov.name} · ${prov.model}",
            fontSize = 11.sp, modifier = Modifier.padding(horizontal = 12.dp)
        )
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.Bottom) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Опиши задачу или вставь код…") }, maxLines = 6
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { chat.ask(scope, input); input = "" }, enabled = !chat.loading) { Text("→") }
        }
    }
}

@Composable
fun EmptyState(onPick: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Image(painterResource(R.drawable.ic_launcher), null, Modifier.size(96.dp).clip(RoundedCornerShape(24.dp)))
        Spacer(Modifier.height(12.dp))
        Text("Чем помочь с кодом?", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Спроси что угодно или выбери пример", fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        listOf(
            "Быстрая сортировка python", "Git отменить коммит", "SQL JOIN примеры",
            "Регулярные выражения email", "Kotlin корутины", "Docker команды", "Бинарный поиск java"
        ).forEach { s -> OutlinedButton(onClick = { onPick(s) }) { Text(s) } }
    }
}

@Composable
fun Bubble(msg: Msg) {
    val isUser = msg.role == "user"
    val bg = when {
        msg.error -> Color(0xFF5A1F1F)
        isUser -> MaterialTheme.colorScheme.primaryContainer
        else -> MaterialTheme.colorScheme.surface
    }
    Column(
        Modifier.fillMaxWidth()
            .padding(start = if (isUser) 40.dp else 0.dp, end = if (isUser) 0.dp else 24.dp)
            .background(bg, RoundedCornerShape(14.dp)).padding(10.dp)
    ) { RichText(msg.text) }
}

@Composable
fun LibraryScreen() {
    var q by remember { mutableStateOf("") }
    val list = if (q.isBlank()) Kb.entries.take(300) else Kb.search(q, 50)
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = q, onValueChange = { q = it }, singleLine = true,
            placeholder = { Text("Поиск по ${Kb.entries.size} статьям") },
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        )
        LazyColumn(
            Modifier.padding(horizontal = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            contentPadding = PaddingValues(bottom = 12.dp)
        ) { items(list) { EntryCard(it) } }
    }
}

@Composable
fun EntryCard(e: Entry) {
    var open by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
            .clickable { open = !open }.padding(12.dp)
    ) {
        Text(e.title, fontWeight = FontWeight.Bold)
        Text(e.lang, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
        if (open) { Spacer(Modifier.height(6.dp)); RichText(e.body) }
    }
}

@Composable
fun AboutScreen() {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(painterResource(R.drawable.ic_launcher), null, Modifier.size(120.dp).clip(RoundedCornerShape(30.dp)))
        Spacer(Modifier.height(12.dp))
        Text("Coding Bot 2.0", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Помощник по программированию.\n\n" +
            "• Офлайн-режим: поиск по встроенной базе знаний (${Kb.entries.size} статей), без интернета и ключей.\n" +
            "• Онлайн-режим: подключи Gemini, Groq, OpenRouter, Claude, OpenAI или свой сервер и добавь ключ в Настройках.\n" +
            "• Темы: встроенные и свои.\n\n" +
            "Офлайн-режим не генерирует новый код, он находит готовые примеры. Для настоящего диалога нужен онлайн-провайдер."
        )
    }
}

@Composable
fun SectionTitle(t: String) =
    Text(t, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 12.dp))

@Composable
fun RadioRow(title: String, sub: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Column {
            Text(title)
            if (sub.isNotEmpty()) Text(sub, fontSize = 12.sp, color = LocalContentColor.current.copy(alpha = 0.6f))
        }
    }
}

@Composable
fun SettingsScreen(
    store: Store, chat: ChatState,
    themeName: String, onTheme: (String) -> Unit,
    custom: List<ThemeDef>, onCustom: (List<ThemeDef>) -> Unit,
    fontScale: Float, onFont: (Float) -> Unit
) {
    var providers by remember { mutableStateOf(store.providers) }
    var active by remember { mutableStateOf(store.activeId) }
    var useKb by remember { mutableStateOf(store.useKb) }
    var editing by remember { mutableStateOf<Provider?>(null) }
    var picking by remember { mutableStateOf(false) }
    var themeEdit by remember { mutableStateOf(false) }
    val all = Presets.themes + custom

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        SectionTitle("Режим ИИ")
        RadioRow("📚 Офлайн (встроенная база знаний)", "Работает без интернета и без ключей", active == "") {
            active = ""; store.activeId = ""
        }
        providers.forEach { p ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    RadioRow(p.name, p.model + if (p.apiKey.isBlank()) " · нет ключа" else "", active == p.id) {
                        active = p.id; store.activeId = p.id
                    }
                }
                TextButton(onClick = { editing = p }) { Text("✎") }
                TextButton(onClick = {
                    providers = providers.filter { it.id != p.id }
                    store.providers = providers
                    if (active == p.id) { active = ""; store.activeId = "" }
                }) { Text("🗑") }
            }
        }
        OutlinedButton(onClick = { picking = true }) { Text("+ Добавить провайдера / ключ") }
        Text(
            "Бесплатные ключи: aistudio.google.com (Gemini), console.groq.com, openrouter.ai. " +
            "Названия моделей можно менять (✎), если сервис их обновил.",
            fontSize = 12.sp
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Подмешивать базу знаний в онлайн-запросы", Modifier.weight(1f))
            Switch(checked = useKb, onCheckedChange = { useKb = it; store.useKb = it })
        }

        SectionTitle("Темы")
        all.forEach { t ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    RadioRow(t.name, if (t.builtin) "встроенная" else "своя", themeName == t.name) { onTheme(t.name) }
                }
                Box(Modifier.size(22.dp).background(hex(t.accent), CircleShape).border(1.dp, Color.Gray, CircleShape))
                if (!t.builtin) {
                    TextButton(onClick = {
                        onCustom(custom.filter { it.name != t.name })
                        if (themeName == t.name) onTheme(Presets.themes[0].name)
                    }) { Text("🗑") }
                }
            }
        }
        OutlinedButton(onClick = { themeEdit = true }) { Text("+ Создать свою тему") }

        SectionTitle("Размер текста: ${(fontScale * 100).toInt()}%")
        Slider(value = fontScale, onValueChange = onFont, valueRange = 0.8f..1.5f)

        SectionTitle("Данные")
        OutlinedButton(onClick = { chat.clear() }) { Text("Очистить историю чата") }
        Spacer(Modifier.height(24.dp))
    }

    if (picking) {
        AlertDialog(
            onDismissRequest = { picking = false },
            title = { Text("Выбери сервис") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Presets.providers.forEach { pr ->
                        TextButton(onClick = { picking = false; editing = pr }) { Text(pr.name) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { picking = false }) { Text("Отмена") } }
        )
    }

    editing?.let { e ->
        ProviderDialog(e, onSave = { np ->
            val saved = if (np.id.isBlank()) np.copy(id = UUID.randomUUID().toString()) else np
            providers = if (providers.any { it.id == saved.id })
                providers.map { if (it.id == saved.id) saved else it } else providers + saved
            store.providers = providers
            editing = null
        }, onDismiss = { editing = null })
    }

    if (themeEdit) {
        ThemeDialog(all.firstOrNull { it.name == themeName } ?: Presets.themes[0], onSave = { nt ->
            val n = if (Presets.themes.any { it.name == nt.name }) nt.name + " (моя)" else nt.name
            val fixed = nt.copy(name = n)
            onCustom(custom.filter { it.name != n } + fixed)
            onTheme(n)
            themeEdit = false
        }, onDismiss = { themeEdit = false })
    }
}

@Composable
fun ProviderDialog(init: Provider, onSave: (Provider) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(init.name) }
    var type by remember { mutableStateOf(init.type) }
    var url by remember { mutableStateOf(init.baseUrl) }
    var key by remember { mutableStateOf(init.apiKey) }
    var model by remember { mutableStateOf(init.model) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Провайдер") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Название") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("anthropic", "openai", "gemini").forEach { t ->
                        FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t) })
                    }
                }
                OutlinedTextField(url, { url = it }, label = { Text("Адрес API") }, singleLine = true)
                OutlinedTextField(
                    key, { key = it }, label = { Text("API-ключ") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )
                OutlinedTextField(model, { model = it }, label = { Text("Модель / версия") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(init.copy(name = name.trim().ifBlank { "Без имени" }, type = type,
                    baseUrl = url.trim(), apiKey = key.trim(), model = model.trim()))
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
fun ColorField(label: String, v: String, on: (String) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(32.dp).background(hex(v), CircleShape).border(1.dp, Color.Gray, CircleShape))
        Spacer(Modifier.width(8.dp))
        OutlinedTextField(v, on, label = { Text(label) }, singleLine = true, modifier = Modifier.weight(1f))
    }
}

@Composable
fun ThemeDialog(init: ThemeDef, onSave: (ThemeDef) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("Моя тема") }
    var bg by remember { mutableStateOf(init.bg) }
    var surface by remember { mutableStateOf(init.surface) }
    var accent by remember { mutableStateOf(init.accent) }
    var text by remember { mutableStateOf(init.text) }
    var user by remember { mutableStateOf(init.user) }
    var code by remember { mutableStateOf(init.code) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новая тема") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Название") }, singleLine = true)
                ColorField("Фон (#RRGGBB)", bg) { bg = it }
                ColorField("Карточки", surface) { surface = it }
                ColorField("Акцент", accent) { accent = it }
                ColorField("Текст", text) { text = it }
                ColorField("Мои сообщения", user) { user = it }
                ColorField("Код", code) { code = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(ThemeDef(name.trim().ifBlank { "Моя тема" }, bg.trim(), surface.trim(),
                    accent.trim(), text.trim(), user.trim(), code.trim()))
            }) { Text("Создать") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
