@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.codingbot

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Kb.load(this)
        setContent { App() }
    }
}

enum class Screen(val title: String, val icon: String) {
    CHAT("Чат", "💬"), LIB("База знаний", "📚"), SETTINGS("Настройки", "⚙️"), ABOUT("О приложении", "ℹ️")
}

class ChatState(val store: Store) {
    val messages = mutableStateListOf<Msg>().apply { addAll(store.chat) }
    var loading by mutableStateOf(false)

    fun clear() { messages.clear(); store.chat = emptyList() }

    fun ask(scope: CoroutineScope, text: String) {
        val t = text.trim()
        if (t.isEmpty() || loading) return
        messages.add(Msg("user", t))
        loading = true
        val snap = messages.toList()
        scope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val prov = store.providers.firstOrNull { it.id == store.activeId }
                    if (prov == null) Kb.answer(t)
                    else Api.chat(prov, snap, if (store.useKb) Kb.context(t) else "")
                }
            }
            r.onSuccess { messages.add(Msg("assistant", it)) }
                .onFailure { messages.add(Msg("assistant", "Ошибка: ${it.message}", true)) }
            store.chat = messages.toList()
            loading = false
        }
    }
}

fun hex(s: String, fallback: Color = Color.Gray): Color =
    try { Color(android.graphics.Color.parseColor(s.trim())) } catch (e: Exception) { fallback }

fun buildScheme(t: ThemeDef): ColorScheme {
    val bg = hex(t.bg); val sf = hex(t.surface); val ac = hex(t.accent); val tx = hex(t.text)
    val base = if (bg.luminance() < 0.5f) darkColorScheme() else lightColorScheme()
    return base.copy(
        primary = ac, onPrimary = bg, background = bg, onBackground = tx,
        surface = sf, onSurface = tx, surfaceVariant = sf, onSurfaceVariant = tx,
        primaryContainer = hex(t.user), onPrimaryContainer = tx,
        secondaryContainer = ac.copy(alpha = 0.25f), onSecondaryContainer = tx,
        tertiary = hex(t.code), outline = tx.copy(alpha = 0.4f)
    )
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    val chat = remember { ChatState(store) }
    val scope = rememberCoroutineScope()
    var themeName by remember { mutableStateOf(store.themeName) }
    var custom by remember { mutableStateOf(store.customThemes) }
    var fontScale by remember { mutableStateOf(store.fontScale) }
    var screen by remember { mutableStateOf(Screen.CHAT) }
    val drawer = rememberDrawerState(DrawerValue.Closed)

    val theme = (Presets.themes + custom).firstOrNull { it.name == themeName } ?: Presets.themes[0]
    val scheme = remember(theme) { buildScheme(theme) }
    val d = LocalDensity.current

    BackHandler(enabled = screen != Screen.CHAT) { screen = Screen.CHAT }

    CompositionLocalProvider(LocalDensity provides Density(d.density, d.fontScale * fontScale)) {
        MaterialTheme(colorScheme = scheme) {
            Surface(Modifier.fillMaxSize(), color = scheme.background) {
                ModalNavigationDrawer(
                    drawerState = drawer,
                    drawerContent = {
                        ModalDrawerSheet {
                            Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                                Image(
                                    painterResource(R.drawable.ic_launcher), null,
                                    Modifier.size(56.dp).clip(RoundedCornerShape(14.dp))
                                )
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text("Coding Bot", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                                    Text("v2.0 · ${Kb.entries.size} статей", fontSize = 12.sp)
                                }
                            }
                            Screen.values().forEach { s ->
                                NavigationDrawerItem(
                                    label = { Text("${s.icon}  ${s.title}") },
                                    selected = s == screen,
                                    onClick = { screen = s; scope.launch { drawer.close() } },
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                ) {
                    Scaffold(
                        containerColor = scheme.background,
                        topBar = {
                            TopAppBar(
                                title = { Text(screen.title) },
                                navigationIcon = {
                                    TextButton(onClick = { scope.launch { drawer.open() } }) {
                                        Text("☰", fontSize = 22.sp)
                                    }
                                },
                                actions = {
                                    if (screen == Screen.CHAT) {
                                        TextButton(onClick = { chat.clear() }) { Text("Очистить") }
                                    }
                                }
                            )
                        }
                    ) { pad ->
                        Box(Modifier.padding(pad).fillMaxSize()) {
                            when (screen) {
                                Screen.CHAT -> ChatScreen(store, chat, scope)
                                Screen.LIB -> LibraryScreen()
                                Screen.SETTINGS -> SettingsScreen(
                                    store, chat, themeName,
                                    { themeName = it; store.themeName = it },
                                    custom, { custom = it; store.customThemes = it },
                                    fontScale, { fontScale = it; store.fontScale = it }
                                )
                                Screen.ABOUT -> AboutScreen()
                            }
                        }
                    }
                }
            }
        }
    }
}
