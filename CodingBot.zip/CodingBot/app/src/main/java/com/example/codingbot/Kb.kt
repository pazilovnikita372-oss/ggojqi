package com.example.codingbot

import android.content.Context

data class Entry(val title: String, val tags: String, val lang: String, val body: String) {
    val titleTokens: List<String> = Kb.tok(title)
    val tagTokens: List<String> = Kb.tok(tags)
}

object Kb {
    var entries: List<Entry> = emptyList()

    private val stop = setOf("как", "что", "для", "это", "the", "and", "how", "to", "in", "на", "по", "из",
        "мне", "надо", "можно", "хочу", "сделать", "напиши", "покажи", "пример", "примеры", "with", "of")

    fun load(ctx: Context) {
        if (entries.isNotEmpty()) return
        val list = mutableListOf<Entry>()
        ctx.assets.list("kb")?.sorted()?.forEach { f ->
            val text = ctx.assets.open("kb/$f").bufferedReader().use { it.readText() }
            text.split(Regex("(?m)^### ")).drop(1).forEach { chunk ->
                val head = chunk.substringBefore('\n')
                val body = chunk.substringAfter('\n', "").trim()
                val parts = head.split("|").map { it.trim() }
                list.add(Entry(parts[0], parts.getOrElse(1) { "" }, parts.getOrElse(2) { "" }, body))
            }
        }
        entries = list
    }

    fun tok(s: String) = s.lowercase()
        .split(Regex("[^\\p{L}\\p{N}#+]+"))
        .filter { it.length >= 2 && it !in stop }

    private fun same(a: String, b: String): Boolean {
        if (a == b) return true
        val n = minOf(a.length, b.length, 5)
        return n >= 4 && a.take(n) == b.take(n)
    }

    fun search(q: String, limit: Int = 3): List<Entry> {
        val qs = tok(q)
        if (qs.isEmpty()) return emptyList()
        return entries.map { e ->
            var s = 0
            for (w in qs) {
                if (e.titleTokens.any { same(it, w) }) s += 5
                if (e.tagTokens.any { same(it, w) }) s += 4
                if (e.body.contains(w, ignoreCase = true)) s += 1
            }
            e to s
        }.filter { it.second > 0 }.sortedByDescending { it.second }.take(limit).map { it.first }
    }

    fun answer(q: String): String {
        val r = search(q, 3)
        if (r.isEmpty()) return "В офлайн-базе ничего не нашлось. Попробуй другие слова " +
            "(например: «сортировка python», «git откат», «sql join») или подключи онлайн-ИИ: " +
            "меню → Настройки → Добавить провайдера."
        return "Нашёл в офлайн-базе:\n\n" + r.joinToString("\n\n") { "**${it.title}**\n${it.body.take(3500)}" }
    }

    fun context(q: String): String {
        val r = search(q, 2)
        if (r.isEmpty()) return ""
        return "\n\nЗаметки из локальной базы знаний (используй, если полезно):\n" +
            r.joinToString("\n---\n") { it.title + "\n" + it.body.take(1800) }
    }
}
