package com.example.codingbot

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Api {
    private const val SYSTEM =
        "You are an expert software engineer and coding assistant. " +
        "Give correct, idiomatic, working code. Put all code in fenced code blocks " +
        "with a language tag. Explain briefly: first the solution, then key points. " +
        "When debugging, find the root cause. Mention edge cases and security issues " +
        "when relevant. Answer in the user's language."

    private fun post(url: String, headers: Map<String, String>, body: JSONObject): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000
        c.readTimeout = 120000
        c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val s = if (code in 200..299) c.inputStream else c.errorStream
        val txt = s?.bufferedReader()?.readText() ?: ""
        if (code !in 200..299) throw RuntimeException("HTTP $code: ${txt.take(400)}")
        return txt
    }

    fun chat(p: Provider, history: List<Msg>, extra: String): String {
        if (p.apiKey.isBlank()) throw RuntimeException("Не указан API-ключ для «${p.name}» (Настройки)")
        val sys = SYSTEM + extra
        val h = history.filter { !it.error }
        val base = p.baseUrl.trim().trimEnd('/')
        return when (p.type) {
            "anthropic" -> {
                val m = JSONArray()
                h.forEach { m.put(JSONObject().put("role", it.role).put("content", it.text)) }
                val r = post(
                    "$base/v1/messages",
                    mapOf("x-api-key" to p.apiKey, "anthropic-version" to "2023-06-01"),
                    JSONObject().put("model", p.model).put("max_tokens", 4096)
                        .put("system", sys).put("messages", m)
                )
                val a = JSONObject(r).getJSONArray("content")
                (0 until a.length()).map { a.getJSONObject(it) }
                    .filter { it.optString("type") == "text" }
                    .joinToString("") { it.getString("text") }
            }
            "gemini" -> {
                val c = JSONArray()
                h.forEach {
                    c.put(JSONObject().put("role", if (it.role == "user") "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", it.text))))
                }
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                    .put("contents", c)
                val r = post("$base/v1beta/models/${p.model}:generateContent?key=${p.apiKey}", emptyMap(), body)
                val parts = JSONObject(r).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts")
                (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }
            }
            else -> {
                val m = JSONArray().put(JSONObject().put("role", "system").put("content", sys))
                h.forEach { m.put(JSONObject().put("role", it.role).put("content", it.text)) }
                val r = post(
                    "$base/chat/completions",
                    mapOf("Authorization" to "Bearer ${p.apiKey}"),
                    JSONObject().put("model", p.model).put("messages", m)
                )
                JSONObject(r).getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").optString("content")
            }
        }
    }
}
