package com.example.codingbot

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Msg(val role: String, val text: String, val error: Boolean = false)

data class Provider(
    val id: String, val name: String, val type: String, // anthropic | openai | gemini
    val baseUrl: String, val apiKey: String, val model: String
)

data class ThemeDef(
    val name: String, val bg: String, val surface: String, val accent: String,
    val text: String, val user: String, val code: String, val builtin: Boolean = false
)

object Presets {
    val providers = listOf(
        Provider("", "Google Gemini", "gemini", "https://generativelanguage.googleapis.com", "", "gemini-2.5-flash"),
        Provider("", "Groq", "openai", "https://api.groq.com/openai/v1", "", "llama-3.3-70b-versatile"),
        Provider("", "OpenRouter", "openai", "https://openrouter.ai/api/v1", "", "qwen/qwen3-coder:free"),
        Provider("", "Anthropic (Claude)", "anthropic", "https://api.anthropic.com", "", "claude-sonnet-5-5"),
        Provider("", "OpenAI", "openai", "https://api.openai.com/v1", "", "gpt-4o-mini"),
        Provider("", "Свой (OpenAI-совместимый)", "openai", "https://", "", "")
    )
    val themes = listOf(
        ThemeDef("Тёмная", "#0F1115", "#1A1D24", "#4FC3F7", "#E6E6E6", "#1F3A5A", "#B5E8A8", true),
        ThemeDef("Светлая", "#FAFAFA", "#EDEFF3", "#1565C0", "#1B1B1B", "#BBDEFB", "#2E7D32", true),
        ThemeDef("Киберпанк", "#0D0221", "#1B0B3B", "#FF2A6D", "#F5F5F5", "#3D1A6B", "#05D9E8", true),
        ThemeDef("Матрица", "#000000", "#0A140A", "#00FF41", "#B8FFB8", "#0F2A0F", "#00FF41", true),
        ThemeDef("Закат", "#1C1018", "#2B1823", "#FF9E64", "#F4E4E4", "#4A2638", "#FFD580", true)
    )
}

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("cfg2", Context.MODE_PRIVATE)

    var providers: List<Provider>
        get() {
            val a = JSONArray(p.getString("providers", "[]") ?: "[]")
            return (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Provider(o.getString("id"), o.getString("name"), o.getString("type"),
                    o.getString("baseUrl"), o.getString("apiKey"), o.getString("model"))
            }
        }
        set(v) {
            val a = JSONArray()
            v.forEach {
                a.put(JSONObject().put("id", it.id).put("name", it.name).put("type", it.type)
                    .put("baseUrl", it.baseUrl).put("apiKey", it.apiKey).put("model", it.model))
            }
            p.edit().putString("providers", a.toString()).apply()
        }

    var activeId: String
        get() = p.getString("active", "") ?: ""
        set(v) { p.edit().putString("active", v).apply() }

    var themeName: String
        get() = p.getString("theme", "Тёмная") ?: "Тёмная"
        set(v) { p.edit().putString("theme", v).apply() }

    var fontScale: Float
        get() = p.getFloat("font", 1f)
        set(v) { p.edit().putFloat("font", v).apply() }

    var useKb: Boolean
        get() = p.getBoolean("usekb", true)
        set(v) { p.edit().putBoolean("usekb", v).apply() }

    var customThemes: List<ThemeDef>
        get() {
            val a = JSONArray(p.getString("themes", "[]") ?: "[]")
            return (0 until a.length()).map {
                val o = a.getJSONObject(it)
                ThemeDef(o.getString("name"), o.getString("bg"), o.getString("surface"),
                    o.getString("accent"), o.getString("text"), o.getString("user"), o.getString("code"))
            }
        }
        set(v) {
            val a = JSONArray()
            v.forEach {
                a.put(JSONObject().put("name", it.name).put("bg", it.bg).put("surface", it.surface)
                    .put("accent", it.accent).put("text", it.text).put("user", it.user).put("code", it.code))
            }
            p.edit().putString("themes", a.toString()).apply()
        }

    var chat: List<Msg>
        get() {
            val a = JSONArray(p.getString("chat", "[]") ?: "[]")
            return (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Msg(o.getString("role"), o.getString("text"), o.optBoolean("error"))
            }
        }
        set(v) {
            val a = JSONArray()
            v.takeLast(60).forEach {
                a.put(JSONObject().put("role", it.role).put("text", it.text).put("error", it.error))
            }
            p.edit().putString("chat", a.toString()).apply()
        }
}
